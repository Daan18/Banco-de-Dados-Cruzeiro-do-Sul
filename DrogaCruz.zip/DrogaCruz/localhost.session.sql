USE drogacruz;

SELECT * FROM produtos;